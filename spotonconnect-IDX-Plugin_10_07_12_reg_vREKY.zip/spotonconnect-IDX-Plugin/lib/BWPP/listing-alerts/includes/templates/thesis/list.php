	<div class="la-body la-list">
		<?php do_action('list_alerts_list'); ?>
	</div>