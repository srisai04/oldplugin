<?php
/**
* Listing Alert Wizard Template
*/
get_header();
?>

<div id="primary">
	<div id="content" role="main" class="la-wizard-body">
		<?php do_action('list_alerts_wizard'); ?>
	</div>
</div>

<?php get_footer(); ?>