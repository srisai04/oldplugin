	<div class="la-body la-edit">
		<?php do_action('list_alerts_edit'); ?>
	</div>