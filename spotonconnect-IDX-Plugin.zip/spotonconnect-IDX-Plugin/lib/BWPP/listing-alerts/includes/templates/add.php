<?php get_header(); ?>

<div id="soidx-content-sidebar-wrapper" class="soidx-la-create">
	<?php do_action('list_alerts_add'); ?>
<!-- Begin Form -->
<form class="formEl_a" method="post" action="<?php echo add_query_arg(array('la_action' => 'list')); ?>">
<?php wp_nonce_field('idx_listing_alerts_add', '_lanonce'); ?>
<div class="cf">
<div class="dp25">
<div class="large bld">Location</div>
	<div class="sepH_a dp100">
	<?php echo spoton_get_states(); ?>
	</div>
	<div class="sepH_a dp100">
	<?php echo spoton_get_counties(); ?>
	</div>
	<div class="sepH_a dp100">
	<?php echo spoton_get_cities(); ?>
	</div>
	<div class="sepH_a dp100">
	<?php echo spoton_get_areas(); ?>
	</div>
	<div class="sepH_a dp100">
	<?php echo spoton_get_subdivisions(); ?>
	</div>
	<div class="sepH_a dp100">
	<label class="lbl_a" for="spto_zipcode">Zip Code</label>
	<input type="text" id="spto_zipcode" name="spto_zipcode" class="inpt_a medium" />
	</div>
</div><!-- end column 1 -->
<div class="dp25">
<div class="large bld">Price Range</div>
<div class="sepH_a dp100">
<?php spoton_get_prices(); ?>
</div>
<div class="sepH_a dp100">
<?php spoton_get_prices(true); ?>
</div>

</div>
<div class="dp25">
<div class="large bld">Features</div>
<div class="sepH_a dp100">
<?php spoton_get_sff_rooms(); ?>
</div>
<div class="sepH_a dp100">
<?php spoton_get_sff_rooms(true); ?>
</div>
<div class="sepH_a dp100">
<?php spoton_get_sff_sqfeet(); ?>
</div>
<div class="sepH_a dp100">
<?php spoton_get_acres(); ?>
</div>
<div class="sepH_a dp100">
<?php spoton_get_acres(true); ?>
</div>

</div>
<div class="dp25">
<div class="large bld">Property Type</div>
<div class="sepH_a dp100">
<?php echo spoton_get_proptype(); ?>
</div>
<div class="large bld">Property Status</div>
<div class="sepH_a dp100">
<?php echo spoton_get_property_status(); ?>
</div>
</div>
<div class="dp25">
<div class="large bld">Other Features</div>
<div class="sepH_a dp100">
<?php spoton_get_sff_tom('medium'); ?>
</div>
</div>
<div class="dp25">
<div class="sepH_a dp100">
<div class="large bld">Show Only</div>
<input type="checkbox" id="spto_viewproperty" value="viewproperty" name="spto_viewproperty" <?php if(!empty($_POST["spto_viewproperty"])) {print 'checked';} ?>>&nbsp;&nbsp;View Properties</input><br />
<input type="checkbox" id="spto_waterfront" value="waterfront" name="spto_waterfront" <?php if(!empty($_POST["spto_waterfront"])) {print 'checked';} ?>>&nbsp;&nbsp;Water Front</input>
</div>
</div>
</div>

<?php
	$sff_filters = spoton_get_sff_filters();
?>

<script type="text/javascript" src="https://xpioimages.blob.core.windows.net/media/datajs-1.0.1.min.js"></script>   
<script type="text/javascript">
jQuery(function(){
var PKey = <?php echo $spoton_pkey; ?>;
var serviceUri = "http://realestateservice.cloudapp.net/odataservice.svc/";
<?php if (1 != $sff_filters['State']) { ?>
loadState();
<?php } ?>
<?php if (1 != $sff_filters['City']) { ?>
jQuery("#spto_city").ready(onLoadCity);
<?php } ?>
jQuery("#spto_county").change(onSelectChangeCounty);

function onLoadCity(){        
    var zipcode =  "<?php echo !empty($_POST['spto_zipcode']) ? $_POST['spto_zipcode'] : ''; ?>";
    jQuery("#spto_zipcode").val(zipcode);
    var city = "<?php echo !empty($_POST['spto_city']) ? $_POST['spto_city'] : ''; ?>";
    jQuery("#spto_city").val(city); 
    var agentid =  "<?php echo !empty($_POST['spto_agentid']) ? $_POST['spto_agentid'] : ''; ?>";
    jQuery("#spto_agentid").val(agentid);        
    var officeid = "<?php echo !empty($_POST['spto_officeid']) ? $_POST['spto_officeid'] : ''; ?>";
    jQuery("#spto_officeid").val(officeid); 
    var schooldistrict =  "<?php echo !empty($_POST['spto_schooldistrict']) ? $_POST['spto_schooldistrict'] : ''; ?>";
    jQuery("#spto_schooldistrict").val(schooldistrict);        
}
function onSelectChangeCounty(){
	var selected = jQuery("#spto_county option:selected");    
	var county = selected.val();    
    loadCity(jQuery("#spto_state").val(),county.replace("_"," ").replace("_"," ").replace("_"," "));
}   
   
    function loadState()
    {
        jQuery("#spto_state >option").remove();
        
		var query ="$filter=PKey eq "+ PKey;   
		var requestUri = serviceUri + "RetsCounties?" + query +"&$select=State&$top=1";
		OData.defaultHttpClient.enableJsonpCallback = true;
		OData.read(requestUri, function (data, request) {
		for (var i = 0; i < data.results.length; i++) {
			jQuery("#spto_state").append('<option value='+data.results[i].State.replace(" ","_").replace(" ","_").replace(" ","_")+'>'+data.results[i].State+'</option>');
            loadCounty(data.results[i].State);
            loadCity(data.results[i].State,0);
		}
		}, function(err){
            alert("Error occurred " + err.message);
        });
    }
    function loadCounty(state)
    {
        jQuery("#spto_county >option").remove();
        jQuery("#spto_county").append('<option value=0>All</option>');
                    
		var query ="$filter=PKey eq "+ PKey +"and State eq '"+state+"'";   
		var requestUri = serviceUri + "RetsCounties?" + query +"&$orderby=County&$select=County";
		OData.defaultHttpClient.enableJsonpCallback = true;
		OData.read(requestUri, function (data, request) {
		for (var i = 0; i < data.results.length; i++) {
		    jQuery("#spto_county").append('<option value='+data.results[i].County.replace(" ","_").replace(" ","_").replace(" ","_")+'>'+data.results[i].County+'</option>');
		}
		}, function(err){
            alert("Error occurred " + err.message);
        });        
    }
    function loadCity(state,county)
    {
        jQuery("#spto_city >option").remove();
        jQuery("#spto_city").append('<option value=0>All</option>');
		
		var query =""        
		if(county==0)
			query="$filter=PKey eq "+ PKey +"and State eq '"+state+"'";            
		else
			query="$filter=PKey eq "+ PKey +"and State eq '"+jQuery("#spto_state").val()+"' and County eq '"+county+"'";
            
		var requestUri = serviceUri + "RetsCities?" + query +"&$orderby=City&$select=City";
		OData.defaultHttpClient.enableJsonpCallback = true;
		OData.read(requestUri, function (data, request) {
		for (var i = 0; i < data.results.length; i++) { 
            var previous=i;
            --previous; 
            if(previous==-1)
            {
                previous=0;
                jQuery("#spto_city").append('<option value='+data.results[i].City.replace(" ","_").replace(" ","_").replace(" ","_")+'>'+data.results[i].City+'</option>')
            }
                
            if(data.results[previous].City!=data.results[i].City)
            {
                jQuery("#spto_city").append('<option value='+data.results[i].City.replace(" ","_").replace(" ","_").replace(" ","_")+'>'+data.results[i].City+'</option>');
            }
		}
		}, function(err){
            alert("Error occurred " + err.message);
        });
    }
});
</script>
<!-- Begin Search Form Controls -->
<div class="cf">
<div style="margin: 10px auto; width: 895px; background-color: #F2F4F7; border: 1px solid #C3D0E1; padding: 10px;">
<p>
	<div class="dp100 sepH_a">
	<label for="la_name"><?php _e('A friendly name for your Listing Alert:', 'list-alerts'); ?></label>
	<input class="inpt_a large" type="text" id="la_name" name="la_name"/></div>
	<div class="dp100 sepH_a">
	<label for="la_name"><?php _e('Alert me when there are updates for this listing', 'list-alerts'); ?></label>
	<input type="checkbox" id="la_enable" checked="checked" name="la_enable" /></div>
    <div class="dp100 sepH_a">  Sort by:&nbsp;&nbsp;&nbsp;&nbsp;
        <select style="width:210px" id="spto_pricesort">
            <option value='0'>Price -  High to Low</option>
            <option value='1'>Price -  Low to High</option>
            <option value='2'>Time on market - Newest First</option>
            <option value='3'>Time on market - Oldest First</option>
            <option value='4'>Lot Size - Largest First</option>
            <option value='5'>Lot Size - Smallest First</option>
        </select></div>
	<input type="hidden" id="spto_market" value="1" />
</p>
<button type="submit" class="btn btn_a btn_medium" id="la_submit" name="la_submit"><span><?php _e('Create Alert', 'list-alerts'); ?></span></button>&nbsp;&nbsp;&nbsp;&nbsp;
</div>
<!-- End Search Form Controls -->
</div>
</form>
</div>

<?php get_footer(); ?>