<?php
	$this->add_option_key('BWP_AURL_GENERAL', 'bwp_aurl_general', __('Advanced User Registration/Login', $this->domain));
?>