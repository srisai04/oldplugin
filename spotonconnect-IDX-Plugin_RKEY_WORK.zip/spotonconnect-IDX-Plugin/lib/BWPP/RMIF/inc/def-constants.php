<?php
	$this->add_option_key('BWP_RMIF_GENERAL', 'bwp_rmif_general', __('Contact Form', $this->domain));
?>